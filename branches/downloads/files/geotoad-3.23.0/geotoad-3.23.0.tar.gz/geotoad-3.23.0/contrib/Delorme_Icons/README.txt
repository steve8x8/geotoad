DeLorme Geocaching Icons by Russell Teague <russell%mtnbike.org>

Icon Installation:
==================
1. Copy geocaching.dim to \DeLorme Docs\Symbols
2. Open DeLorme Topo 5
3. Click the 'Draw' tab
4. Click the 'Red Flag' button
5. Choose 'Geocaching' in the Symbols drop down

Then import a file created by GeoToad's "delorme" format type.
